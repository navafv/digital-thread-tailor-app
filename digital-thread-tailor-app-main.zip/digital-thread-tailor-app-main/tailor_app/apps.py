from django.apps import AppConfig


class TailorAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tailor_app'
